const registerdefault = {
    props: {
        model: Object
    }
}

app.component('registerdefault', {
    extends: registerdefault,
    template: '#registerdefault'
});