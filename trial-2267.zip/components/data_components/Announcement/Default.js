const announcementdefault = {
    props: {
        model: Object
    }
}

app.component('announcementdefault', {
    extends: announcementdefault,
    template: '#announcementdefault'
});