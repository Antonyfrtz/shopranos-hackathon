const logindefault = {
    props: {
        model: Object
    }
}

app.component('logindefault', {
    extends: logindefault,
    template: '#logindefault'
});