const topbardefault = {
    props: {
        model: Object
    }
}

app.component('topbardefault', {
    extends: topbardefault,
    template: '#topbardefault'
});