const featuresComponent = {
    data() {
        return {}
    }
}

app.component('textwithimagecustom_textwithimage', {
    extends: featuresComponent,
    template: '#textwithimagecustom_textwithimage'
});