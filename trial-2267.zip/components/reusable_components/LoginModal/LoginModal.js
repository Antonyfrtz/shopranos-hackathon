const loginmodal = {
}

app.component('loginmodal', {
    extends: loginmodal,
    template: '#loginmodal'
});