const custom_hjgh  = {
        props:
            {},
        data() {
            return {
            }
            },
        mounted(){
        }
}

app.component('custom_hjgh', {
    extends: custom_hjgh,
    template: '#custom_hjgh'
});